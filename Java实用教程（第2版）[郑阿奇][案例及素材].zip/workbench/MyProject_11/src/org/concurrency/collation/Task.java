package org.concurrency.collation;
	public interface Task {
		void execute();
	}

