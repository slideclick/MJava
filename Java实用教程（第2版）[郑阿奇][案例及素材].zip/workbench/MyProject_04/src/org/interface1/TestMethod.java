package org.interface1;
	public interface TestMethod {
		void studying();
		void playing();
		void eating();
	}
