package org.approach2;
	import org.approach1.TestAccess1;
	public class TestAccess4 {
		public static void main(String[] args) {
			TestAccess1 access1 = new TestAccess1();
			//System.out.println(access1.var1);
			//System.out.println(access1.var2);
			//System.out.println(access1.var3);
			System.out.println(access1.var4);
			//access1.f1();
			//access1.f2();
			//access1.f3();
			access1.f4();
		}
	}
