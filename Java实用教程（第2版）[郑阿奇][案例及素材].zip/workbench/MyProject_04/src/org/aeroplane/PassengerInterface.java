package org.aeroplane;
public interface PassengerInterface {
	public String getName();
	public int getBookingNumber();
	public int getRow();
	public int getSeatPosition();
}
