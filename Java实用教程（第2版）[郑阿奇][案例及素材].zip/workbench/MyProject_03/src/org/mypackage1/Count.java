package org.mypackage1;
import java.util.Date;
public class Count {
		public void m1(int i, int j) {
			System.out.println(i + j);
		}
		public int m2(int i, int j) {
			return i > j ? i : j;
		}
}

