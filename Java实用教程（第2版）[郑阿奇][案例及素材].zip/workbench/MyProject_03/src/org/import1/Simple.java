package org.import1;
	public class Simple {
		public static final String COUNTRY = "China";
		public static int add(int a, int b) {
    		return a + b;
		}
	}
