package org.import2;
	import static org.import1.Simple.COUNTRY;					// ��̬����
	import static org.import1.Simple.add;
	public class StaticImport {
		public static void main(String[] args) {
			System.out.println(add(3, 9));
			System.out.println(COUNTRY);
		}
	}
