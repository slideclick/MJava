public class TestInitialize {
		public static void main(String[]args){
			Tester t = new Tester();
			System.out.println(t.s);			
		}
	}
	class Tester {
		String s;
	}

