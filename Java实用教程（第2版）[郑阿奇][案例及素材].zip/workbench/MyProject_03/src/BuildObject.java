public class BuildObject {
		BuildObject(){
			System.out.println("invoke BuildObject!");
		}
		public static void main(String[] args){
			BuildObject object = new BuildObject();
		}
	}

