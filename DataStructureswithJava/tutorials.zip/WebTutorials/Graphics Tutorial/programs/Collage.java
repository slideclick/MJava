import ds.graphics.*;

public class Collage
{
	public static void main(String[] args)
	{
		// pointers in the shape (base) class
		Shape[] fPtr = new Shape[3];

		// create a blue circle with radius .75
		fPtr[2] = new CircleShape(0, 0, 0.75, Shape.blue);
		// fPtr[0] = new PolyShape(0, 0, 4, 1, Shape.blue);
		// fPtr[0] = new RectShape(0, 0, 1, .75, Shape.blue);
		// create a blue regular hexagon with sides of
		// length .75
		//fPtr[1] = new PolyShape(0, 0, 6, 0.75, Shape.blue);
		fPtr[1] = new RectShape(0,0,1,1, Shape.blue);
		// create an equilateral triangle with sides of
		// length 1.5
		fPtr[0] = new PolyShape(0, 0, 3, 0.75, Shape.blue);

		// open the drawing window

		Graph.openWindow();

		// create the collage of figures
		for (int i = 0; i < 3; i++)
			collage(fPtr[i]);

		// close the drawing window
		Graph.closeWindow();
	}

	public static void collage(Shape sPtr)
	{
		// the initial color of the shape is blue
		int c = Shape.blue;
		int i;

		// draw 16 shapes, each in a different color
		// arranged in a grid of 4 figures across.
		// the figure base points for the 1st row
		// are (1,1), (3,1), (5,1), (7,1) and
		// for the second row are
		// (1,3), (3,3), (5,3), (7,3), etc.
		for (i = 0; i < 16; i++)
		{
			sPtr.move(2*(i%4) + 1.0, 2*(i/4) + 1.0);
			sPtr.draw();
			if (sPtr instanceof CircleShape)
				sPtr = ((CircleShape)sPtr).copy();
			else if (sPtr instanceof RectShape)
				sPtr = ((RectShape)sPtr).copy();
			else if (sPtr instanceof PolyShape)
				sPtr = ((PolyShape)sPtr).copy();
			c = Shape.nextColor(c);
			sPtr.setColor(c);
		}

		Graph.viewWindow();
		Graph.eraseWindow();
	}
}
