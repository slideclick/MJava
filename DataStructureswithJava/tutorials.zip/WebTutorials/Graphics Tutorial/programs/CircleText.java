import ds.graphics.*;

public class CircleText
{
	public static void main(String[] args)
	{
		CircleShape circ = new CircleShape(5, 4, 1.5 ,Shape.LIGHTBLUE);
		TextShape text = new TextShape(5, 6,"Circle", Shape.BLACK);

		DrawTools.openWindow();
		circ.draw();
		text.draw();
		DrawTools.viewWindow();

		text.erase();
		text.setText("This is a circle");
		text.draw();
		DrawTools.viewWindow();

		text.erase();
		text.setFont(TextShape.CODE12);
		text.draw();
		DrawTools.viewWindow();

		DrawTools.closeWindow();
	}
}
