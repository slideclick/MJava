import ds.graphics.*;

class RectShapeValue<T extends Comparable<T>> implements Comparable<RectShapeValue<T>>
{
	private T value;
	private RectShape rect;
	private TextShape text;

	public RectShapeValue(double x, double y, double length,
	            double width, int color, T value)
	{
		this.value = value;
		rect = new RectShape(x,y,length,width,color);
		text = new TextShape(x + length/2, y + width/2, value.toString(),
			Shape.BLACK, TextShape.TR12B);
	}

	public int compareTo(RectShapeValue<T> rhs)
	{ return value.compareTo(rhs.value); }

	public boolean equals(Object rhs)
	{
		if (rhs instanceof RectShapeValue)
		{
			 return value.equals(((RectShapeValue)rhs).value);
		}
		return false;
	}

	public void move(double x, double y)
	{
		rect.move(x,y);
		text.move(x + rect.getLength()/2, y + rect.getWidth()/2);
	}

	public void draw()
	{
		rect.draw();
		text.draw();
	}

	public void setColor(int color)
	{
		rect.setColor(color);
	}
}

