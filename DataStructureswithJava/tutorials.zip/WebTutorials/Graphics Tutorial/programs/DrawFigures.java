import ds.graphics.*;

public class DrawFigures
{
	public static void main(String[] args)
	{
		CircleShape circ = new CircleShape(2.0,2.0,1.0, Shape.LIGHTGRAY);
		RectShape rect = new RectShape(4.5,1.0,2.75,1.75,Shape.DARKGRAY);
		LineShape line = new LineShape(1.5,6.25,3.0,4.75,Shape.GREEN);
		PolyShape poly = new PolyShape(6.0,5.5, 6,1.4, Shape.YELLOW);
		TextShape text = new TextShape(4.0,3.75, "Graphics Figures", Shape.BLACK);

		DrawTools.openWindow();

		circ.draw();
		rect.draw();
		line.draw();
		poly.draw();
		text.draw();

		DrawTools.viewWindow();
		DrawTools.closeWindow();
	}
}
