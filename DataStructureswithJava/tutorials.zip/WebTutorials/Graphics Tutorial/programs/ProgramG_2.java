import ds.graphics.*;

public class ProgramG_2
{
	public static void main(String[] args)
	{
		// create the yoyo and the string
		CircleShape yoyo = new CircleShape(5,6,0.5, Shape.RED);
		LineShape string = new LineShape(5,1,5,6,Shape.DARKGRAY);

		double yValue, changeValue = 0.2;


		// the loop provides animation
		while (true)
		{
			string.draw();
			yoyo.draw();
			DrawTools.delayWindow(0.1);

			string.erase();
			yoyo.erase();

         	yValue = yoyo.getY();
         	if (yValue > 6.0 || yValue < 2.0)
         	changeValue = -changeValue;
        	yValue += changeValue;
        	yoyo.move(5,yValue);
        	string.setEndPoint(5,yValue);
		}
	}
}