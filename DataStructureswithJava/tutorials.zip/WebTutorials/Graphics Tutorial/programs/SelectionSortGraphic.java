import ds.graphics.*;

class RectShapeValue extends RectShape implements Comparable
{
	private Object value;
	private TextShape text;

	public RectShapeValue()
	{
		super();
		value = null;
		text = new TextShape();
	}

	public RectShapeValue(double x, double y, double length,
	            double width, Object value, int color)
	 {
		 super(x,y,length,width,color);
		 this.value = value;
		 text = new TextShape(x+length/2, y+width/2,value.toString(), Shape.BLACK);
	 }

	 public Object getValue()
	 { return value; }

	 public void setValue(Object value)
	 { this.value = value; }

	 public int compareTo(Object rhs)
	 { return ((Comparable)value).compareTo(((RectShapeValue)rhs).value); }

	 public boolean equals(Object rhs)
	 { return value.equals(((RectShapeValue)rhs).value); }

	 public void draw()
	 {
		 super.draw();
		 text.draw();
	 }
 }

public class SelectionSortGraphic
{

	static TextShape label = new TextShape(1,1.5,"",Shape.BLACK);;

	public static void main(String[] args)
	{
		int[] intArr = {7, 5, 8, 2, 9, 4, 3};
		RectShapeValue[] arr = new RectShapeValue[intArr.length];
		RectShape rect;
		int i;

		for (i = 0; i < intArr.length; i++)
		{
			arr[i] = new RectShapeValue(0,0,0.75, 0.75, new Integer(intArr[i]), Shape.LIGHTGRAY);
		}

		DrawTools.openWindow();
		displayList(arr, "Initial List");
		DrawTools.viewWindow();

		selectionSortGraphic(arr);
		displayList(arr, "Final sorted list");
		DrawTools.viewWindow();
		DrawTools.closeWindow();
	}

	public static void displayList(RectShapeValue[] arr, String msg)
	{
		int i;

		for (i = 0; i < arr.length; i++)
		{
			arr[i].move(1+i, 2);
			arr[i].draw();
		}

		label.erase();
		label.setText(msg);
		label.draw();
	}

	public static void selectionSortGraphic(RectShapeValue[] arr)
	{
		int smallIndex; // index of smallest element in the sublist
			int pass, j, n = arr.length;
		RectShapeValue temp;

		// pass has the range 0 to n-2
		for (pass = 0; pass < n-1; pass++)
		{
			// scan the sublist starting at index pass
			smallIndex = pass;

			// j traverses the sublist arr[pass+1] to arr[n-1]
			for (j = pass+1; j < n; j++)
				// if smaller element found, assign smallIndex
				// to that position
				if (((Comparable)arr[j]).compareTo(arr[smallIndex]) < 0)
					smallIndex = j;
			arr[smallIndex].setColor(Shape.RED);
			displayList(arr,("In pass " + Integer.toString(pass)));
			DrawTools.delayWindow(2);

			// swap the next smallest element into arr[pass]
			temp = arr[pass];
			arr[pass] = arr[smallIndex];
			arr[smallIndex] = temp;

			arr[pass].setColor(Shape.LIGHTBLUE);
			if (pass != smallIndex)
				arr[smallIndex].setColor(Shape.LIGHTGRAY);
			displayList(arr,("After pass " + Integer.toString(pass)));
			DrawTools.viewWindow();
		}
	}
}


