import ds.graphics.*;

public class TestDraw
{
	public static void main(String[] args)
	{
		// pointers in the shape (base) class
		CircleShape c = new CircleShape(2, 4, 1, Shape.BLUE);
		// RectShape c = new RectShape(1, 5, 2, 2, Shape.blue);
		PolyShape p = new PolyShape(2, 3, 6, 0.25, Shape.ORANGE);

		// create a blue circle with radius .75
		/*fPtr[0] = new CircleShape(0, 0, 0.75, Shape.blue);
		// create a blue regular hexagon with sides of
		// length .75
		// create an equilateral triangle with sides of
		// length 1.5
		fPtr[2] = new PolyShape(0, 0, 3, 1.5, Shape.blue);*/

		// open the drawing window

		GraphLib.openWindow();

		// p.draw();
		c.draw();
		GraphLib.delayWindow(1);
		c.setColor(Shape.RED);
		c.move(8,3);
		c.draw();
		//c.draw();
		p.draw();

		GraphLib.viewWindow();

		// close the drawing window
		GraphLib.closeWindow();
	}
}
