import ds.graphics.*;

public class ProgramG_5
{
	static TextShape label = new TextShape(1,1.5,"",Shape.BLACK);;

	public static void main(String[] args)
	{
		Integer[] arr = {7, 5, 8, 2, 9, 4, 3};
		RectShapeValue<Integer>[] gArr = new RectShapeValue[arr.length];
		RectShape rect;
		int i;

		for (i = 0; i < arr.length; i++)
		{
			gArr[i] = new RectShapeValue<Integer>(0, 0, 0.75, 0.75, Shape.LIGHTGRAY, arr[i]);
		}

		DrawTools.openWindow();
		displayList(gArr, "Initial List");
		DrawTools.viewWindow();

		selectionSortGraphic(gArr);
		displayList(gArr, "Final sorted list");
		DrawTools.viewWindow();
		DrawTools.closeWindow();
	}

	public static <T extends Comparable<T>> void displayList(RectShapeValue<T>[] gArr, String msg)
	{
		int i;

		for (i = 0; i < gArr.length; i++)
		{
			gArr[i].move(1+i, 2);
			gArr[i].draw();
		}

		label.erase();
		label.setText(msg);
		label.draw();
	}

	public static <T extends Comparable<T>> void selectionSortGraphic(RectShapeValue<T>[] gArr)
	{
		// index of smallest element in the sublist
		int smallIndex;

		// variables to handle the sort
		int pass, j, n = gArr.length;
		RectShapeValue temp;

		// pass has the range 0 to n-2
		for (pass = 0; pass < n-1; pass++)
		{
			// scan the sublist starting at index pass
			smallIndex = pass;

			// j traverses the sublist arr[pass+1] to arr[n-1]
			for (j = pass+1; j < n; j++)
				// if smaller element found, assign smallIndex to that position
				if (gArr[j].compareTo(gArr[smallIndex]) < 0)
					smallIndex = j;

			// color red identifies the index of smallest element; display list
			gArr[smallIndex].setColor(Shape.RED);
			displayList(gArr,("In pass " + Integer.toString(pass)));
			DrawTools.delayWindow(2);

			// swap the next smallest element into arr[pass]
			temp = gArr[pass];
			gArr[pass] = gArr[smallIndex];
			gArr[smallIndex] = temp;

			// set color to light blue; it is in the right position
			gArr[pass].setColor(Shape.LIGHTBLUE);
			displayList(gArr,("After pass " + Integer.toString(pass)));
			DrawTools.viewWindow();
		}

		// set last element to blue; it is correct
		gArr[pass].setColor(Shape.LIGHTBLUE);
	}
}


