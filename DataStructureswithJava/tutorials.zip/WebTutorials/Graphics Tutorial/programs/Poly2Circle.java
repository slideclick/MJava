import ds.graphics.*;             // use polygon shapes

public class Poly2Circle
{
	public static void main(String[] args)
	{
		// n is number of polygon sides
		int n;
		// length of each polygon side
		double side;

		// position center of polygons at (5,4)
		PolyShape poly = new PolyShape();

		poly.setColor(Shape.WHITE);       // all polygons are blue
		poly.move(5,4);

		DrawTools.openWindow();              // open drawing window

		// draw polygons with 3 to 20 sides and perimeter 10
		for(n=4; n <= 20; n = n + 2)
		{
			side = 20.0/n;          // length of each side
			poly.setLength(side);   // set side length
			poly.setN(n);           // number of sides is n
			poly.nextColor();
			poly.draw();            // draw polygon
			DrawTools.delayWindow(2);        // wait 1/2 second
			poly.erase();           // erase the polygon
		 }

		 // draw 120-sided polygon
		 side = 20.0/120;
		 poly.setLength(side);
		 poly.setN(120);
		 poly.nextColor();
		 poly.draw();
		 DrawTools.viewWindow();

		 DrawTools.closeWindow();             // shut down the window
	}
}

/*
Run:
    (Five of the figures are drawn in Figure 6.4)
*/
