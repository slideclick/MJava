import ds.graphics.*;

public class ProgramG_1
{
	public static void main(String[] args)
	{
		// create a 7 by 6 BLUE rectangle at base point (1,1)
		RectShape rect = new RectShape(1,1,8,6,Shape.BLUE);
		int i;

		// open the drawing window and draw first rectangle
		DrawTools.openWindow();
		rect.draw();

		// each iteration moves the base point right and down 1/2 unit
		// reduces each dimension by 1 unit and selects the next
		// color in the palette before redrawing the figure
		for (i = 1; i <= 5; i++)
		{
			rect.move(rect.getX() + 0.5, rect.getY() + 0.5);
			rect.setSides(rect.getLength() - 1, rect.getWidth() - 1);
			rect.nextColor();
			rect.draw();
		}

		// view the window and close the graphics system
		DrawTools.viewWindow();
		DrawTools.closeWindow();
	}
}