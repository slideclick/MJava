import ds.graphics.*;

public class ProgramGP_5
{
	public static void main(String[] args)
	{
		int[] intArr = {7, 5, 8, 2, 9, 4, 3};
		Integer[] arr = new Integer[intArr.length];
		int i;

		for (i = 0; i < intArr.length; i++)
			arr[i] = new Integer(intArr[i]);

		selectionSortGraphic(arr);
	}

	public static void displayList(Object[] arr, RectShape[] gArr, String header)
	{
		int i;

		// clear current window
		DrawTools.eraseWindow();

		// display each element (square) with the value in the center
		for (i = 0; i < arr.length; i++)
		{

			// draw rectangle
			gArr[i].draw();

			// create TextShape value string and draw it,
			TextShape text = new TextShape(1.375 + i, 2.40, arr[i].toString(), Shape.BLACK);
			text.draw();
		}

		// create header and draw it
		TextShape label = new TextShape(1,1.5,header,Shape.BLACK);;
		label.draw();
	}

	public static void selectionSortGraphic(Object[] arr)
	{
		// setup variables and loop for the graphical object
		RectShape[] gArr = new RectShape[arr.length];
		int i;

		for (i = 0; i < arr.length; i++)
			gArr[i] = new RectShape(1 + i,2,0.75, 0.75, Shape.LIGHTGRAY);

		int smallIndex; // index of smallest element in the sublist
			int pass, j, n = arr.length;
		Object temp;

		// open window, display the initial list, pause for user
		DrawTools.openWindow();
		displayList(arr, gArr, "Initial List");
		DrawTools.viewWindow();

		// pass has the range 0 to n-2
		for (pass = 0; pass < n-1; pass++)
		{
			// scan the sublist starting at index pass
			smallIndex = pass;

			// j traverses the sublist arr[pass+1] to arr[n-1]
			for (j = pass+1; j < n; j++)
				// if smaller element found, assign smallIndex
				// to that position
				if (((Comparable)arr[j]).compareTo(arr[smallIndex]) < 0)
					smallIndex = j;
			gArr[smallIndex].setColor(Shape.RED);
			displayList(arr,gArr, ("In pass " + Integer.toString(pass)));
			DrawTools.delayWindow(2);

			// swap the next smallest element into arr[pass]
			temp = arr[pass];
			arr[pass] = arr[smallIndex];
			arr[smallIndex] = temp;

			gArr[pass].setColor(Shape.LIGHTBLUE);
			if (pass != smallIndex)
				gArr[smallIndex].setColor(Shape.LIGHTGRAY);
			displayList(arr,gArr, ("After pass " + Integer.toString(pass)));
			DrawTools.viewWindow();
		}

		// color last element LIGHTBLUE, display list, pause for user
		// then close the drawingwindow
		gArr[pass].setColor(Shape.LIGHTBLUE);

		displayList(arr, gArr, "Final sorted list");
		DrawTools.viewWindow();
		DrawTools.closeWindow();
	}
}


