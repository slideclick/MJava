import ds.graphics.*;

public class Bullseye
{
	public static void main(String[] args)
	{
		// the light blue 4 x 4 square
		RectShape square = new RectShape(3.0,2.0,4.0,4.0,Shape.blue);

		// circle that grows to size of the square
		CircleShape circ = new CircleShape(5.0,4.0,0,Shape.lightgray);

		// diagonal lines in the square
		LineShape diag1 = new LineShape(3.0,2.0,7.0,6.0,Shape.black),
					 diag2 = new LineShape(3.0,6.0,7.0,2.0,Shape.black);

		// display message after the circle hits the bulls-eye
		TextShape text = new TextShape(4.1,6.4,"That's All Folks", Shape.black);

		// initial radius of the circle
		double r = 0.125;

		// open the drawing window and draw the square
		Graph.openWindow();
		square.draw();

		do
		{
			// set the radius and draw the circle
			circ.setRadius(r);
			circ.draw();

			// increase radius by 0.125
			r += 0.125;

			// pause 1/10 second and then proceed
			Graph.delayWindow(.1);
		} while (r <= 2.0);

		// draw the diagonals for the square
		diag1.draw();
		diag2.draw();

		// draw the label "That's All Folks"
		text.draw();

		// pause to view the final figure
		Graph.viewWindow();

		// shutdown the drawing system
		Graph.closeWindow();
	}
}
