import ds.graphics.*;

public class ProgramGP_3
{
	public static void main(String[] args)
	{
		// the red 4 x 4 square
		RectShape square = new RectShape(3,2,4,4,Shape.LIGHTBLUE);

		// circle that moves toward the bulls-eye
		CircleShape circ = new CircleShape(5,4,0,Shape.RED);

		// diagonal lines in the square
		LineShape diag1 = new LineShape(3,2,7,6,Shape.BLACK),
				    diag2 = new LineShape(3,6,7,2,Shape.BLACK);

		// display message after the circle hits the bulls-eye
		TextShape text = new TextShape(5,6.25,"Bulls-Eye", Shape.BLACK);

		// initial radius of the circle
		double r = 2;


		// open the drawing window
		DrawTools.openWindow();

		// 8 steps to bulls-eye
		for (int i = 1; i <= 8; i++)
		{
			// display the square
			square.draw();

			// set the radius of the circle and draw it
			circ.setRadius(r);
			circ.draw();

			// draw the diagonals (the X)
			diag1.draw();
			diag2.draw();

			// pause 1/2 second and then erase the circle
			DrawTools.delayWindow(.5);
			circ.erase();

			// keep same center but decrease the radius of the circle
			r -= 0.25;
		}

		// the last circ.erase() affected the X. redraw it
		diag1.draw();
		diag2.draw();
		// draw "Bulls-Eye"
		text.draw();

		// pause to view the final figure
		DrawTools.viewWindow();
		// shutdown the drawing system
		DrawTools.closeWindow();
	}
}

/*
Run:
    (Five of the figures are drawn in Figure 6.4)
*/
