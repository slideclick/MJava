import java.util.*;

public class ProgramI_1
{
	public static void main(String[] args)
	{
		// variables used for strings, objects and result
		int result;
		String infixStr = "", postfixStr = "";
		InfixToPostfix infixObj = new InfixToPostfix();
		PostfixEval postfixObj = new PostfixEval();

		// Scanner keyIn reads infix expression from the keyboard
		Scanner keyIn = new Scanner(System.in);

		// input the infix expression and assign to infixObj
		System.out.print("Enter infix expression: ");
		infixStr = keyIn.nextLine();
		infixObj.setInfixExp(infixStr);

		// convert to postfix expression; catch any error in the
		// conversion to postfix, and output the message
		try
		{
			postfixStr = infixObj.toPostfix();
			System.out.println("    Postfix: " + postfixStr);
		}
		// catch block outputs the error and terminates program
		catch (ArithmeticException exc)
		{
			System.out.println("    " + exc.getMessage());
			System.exit(1);
		}

		// no errors so assign postfix expression to postfixObj
		// and carry out the calculation
		postfixObj.setPostfixExp(postfixStr);
		result = postfixObj.evaluate();

		// output the result and clear the text field
		System.out.println("    Value = " + result + "\n");
	}
}

/*
Run:

Enter infix expression: 3^2^(1+2)
    Postfix: 3 2 1 2 + ^ ^
    Value = 6561

Enter infix expression: 3 * (4 - 2 ^ 5) + 6
    Postfix: 3 4 2 5 ^ - * 6 +
    Value = -78

Enter infix expression: (7 + 8*7
    InfixToPostfix: Missing ')'

Enter infix expression: (9 + 7) 4
    InfixToPostfix: Operator expected

Enter infix expression: 2*4*8/
    InfixToPostfix: Operand expected
*/

