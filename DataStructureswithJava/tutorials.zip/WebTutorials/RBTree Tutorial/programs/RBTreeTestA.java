import ds.util.*;

public class RBTreeTestA
{
	public static void main(String[] args)
	{
		Integer intArr[] = {23, 35, 55, 46, 8, 67, 6, 63};
		RBTree<Integer> t = new RBTree<Integer>();				// create an empty tree


		for (int i = 0; i < intArr.length; i++)
			t.add(intArr[i]);											// insert elements

		System.out.println("RBTree list: " + t);

		System.out.print("Odd integers: ");
		for (Integer n : t)
			if (n % 2 == 1)
				System.out.print(n + "  ");
		System.out.println();

		System.out.println(t.displayTree(3));
		t.drawTree(3);
	}
}
