public interface Accumulator<T>
{
	public void add(T v);
}
