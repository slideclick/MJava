public interface Visitor<T>
{
	public void visit(T obj);
}
