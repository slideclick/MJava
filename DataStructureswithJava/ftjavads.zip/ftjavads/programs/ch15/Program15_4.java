public class Program15_4
{
	public static void main(String[] args)
	{
		// create bank simulation object and start the simulation
		BankSimulation bank = new BankSimulation();
		bank.startSimulation();
	}
}
