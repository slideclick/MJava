// an object that implements View has methods to access and
// update a data item in a backing object
public interface View
{
	int get();
	void set(int value);
}
