// specifies the size and value of an item
public class Item
{
	public int size, value;

	public Item (int size, int value)
	{
		this.size = size;
		this.value = value;
	}
}