package ds.graphics;

import java.awt.*;

public class LineShape extends Shape
{
	private double endX;
	private double endY;

	public LineShape()
	{
    	super(0,0,Shape.BLACK,Shape.DRAW);
    	endX = 0;
    	endY = 0;
  	}

	public LineShape(double x1, double y1, double x2, double y2, int c)
	{
    	super(x1,y1,c,Shape.DRAW);
    	endX = x2;
    	endY = y2;
  	}

	public double getLength()		// length of line
	{
		double dx = endX - x, dy = endY - y;
		return Math.sqrt(dx*dx + dy*dy);
	}

	public void setEndPoint(double x, double y)  // change 2nd point
	{
		endX = x;
		endY = y;
	}

	public LineShape copy()
	{
		LineShape l = new LineShape(x, y, endX,  endY, colorIndex);

		return l;
	}

	public void draw()
	{
		if (DrawTools.openWindowCalled == false)
			DrawTools.openWindow();

		// if(!alist.contains(this))
			alist.add(this);

		DrawPanel panel = DrawTools.getDrawingPanel();

		drawFigure(panel.getGraphics(), panel.getFactor());
	}

	public void drawFigure(Graphics g, double factor)
	{
		g.setColor(colorList[colorIndex]);
		g.drawLine((int)(factor * x),(int)(factor * y),
                 (int)(factor * endX), (int)(factor * endY));
	}
}