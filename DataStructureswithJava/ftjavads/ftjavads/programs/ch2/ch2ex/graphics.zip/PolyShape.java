package ds.graphics;

import java.awt.*;
import java.util.Vector;

public class PolyShape extends Shape
{
	private int numSides; 				// number of sides
	private double length; 				// length of a side
   private double[] point_X, point_Y;

	public PolyShape()
	{
		super(0,0,Shape.LIGHTGRAY,Shape.FILL);
		numSides = 0;
		length = 0;
		setPoints();
	}

	public PolyShape(double x, double y, int n, double len, int c)
	{
		super(x,y,c,Shape.FILL);
		numSides = n;
		length = len;
		setPoints();
	}


	public PolyShape copy()
	{
		PolyShape p = new PolyShape(x, y, numSides,  length, colorIndex);

		return p;
	}

  	private void setPoints()
  	{
		int i;
		double theta, d;
		double PI = Math.PI;
		double DELTA_THETA = (2.0*PI)/numSides;

		point_X = new double[numSides];
		point_Y = new double[numSides];
		d = length/(2.0*Math.sin(PI/numSides));
		theta = 0;
		for(i = 0; i  < numSides; i++)
		{
			point_X[i] = x + d*(Math.cos(theta));
			point_Y[i] = y - d*(Math.sin(theta));
			theta += DELTA_THETA;
		}
	}


   public void setN(int n)
   {
		numSides = n;
		setPoints();
	}

   	public int getN()
   	{ return numSides; }

   	public void setLength(double len)
   	{
		length = len;
		setPoints();
	}

   	public double getLength()
   	{ return length; }

   	public void draw()
   	{
			if (DrawTools.openWindowCalled == false)
				DrawTools.openWindow();

      	if(!alist.contains(this))
        		alist.add(this);

        	setPoints();

			DrawPanel panel = DrawTools.getDrawingPanel();

      	drawFigure(panel.getGraphics(), panel.getFactor());
   	}

   	public void drawFigure(Graphics g, double factor)
   	{
      	int i;
      	int[] xArr = new int[numSides];
      	int[] yArr = new int[numSides];

      	for(i = 0; i < numSides; i++)
      	{
				xArr[i] = (int)(factor * point_X[i]);
				yArr[i] = (int)(factor * point_Y[i]);
      	}

      	g.setColor(colorList[colorIndex]);
      	if(fillValue == Shape.FILL)
        		g.fillPolygon(xArr, yArr, numSides);
      	else
        		g.drawPolygon(xArr, yArr, numSides);
   	}
}