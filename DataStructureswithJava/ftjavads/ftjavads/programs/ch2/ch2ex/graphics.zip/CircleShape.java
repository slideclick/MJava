package ds.graphics;

import java.awt.*;

public class CircleShape extends Shape
{
   	private double radius;

   	public CircleShape()
   	{
    		super(0,0,Shape.LIGHTGRAY,Shape.FILL);
    		radius = 0;
   	}

   	public CircleShape(double x, double y, double r, int c)
   	{
    		super(x,y,c,Shape.FILL);
    		radius = r;
   	}

   	public CircleShape(CircleShape c)
   	{
			super(c.x, c.y, c.colorIndex, c.fillValue);
			radius = c.radius;
   	}

   	public double getRadius()
   	{ return radius; }

   	public void setRadius (double r)
   	{ radius = r; }

   	public void draw()
   	{
			if (DrawTools.openWindowCalled == false)
				DrawTools.openWindow();

      	if(!alist.contains(this))
        		alist.add(this);

			DrawPanel panel = DrawTools.getDrawingPanel();

      	drawFigure(panel.getGraphics(), panel.getFactor());
   	}

   	public CircleShape copy()
   	{
			CircleShape c = new CircleShape(x, y, radius, colorIndex);

			return c;
		}

   	public void drawFigure(Graphics g, double factor)
   	{
      	g.setColor(colorList[colorIndex]);
      	if(fillValue == Shape.FILL)
				g.fillOval((int)(factor * (x-radius)),(int)(factor * (y-radius)),
							(int)(factor * 2 * radius), (int)(factor * 2 * radius));
      	else
				g.drawOval((int)(factor * (x-radius)),(int)(factor * (y-radius)),
							 (int)(factor * 2 * radius),(int)(factor * 2 * radius));
   	}
}