package ds.graphics;

import java.awt.*;

public class TextShape extends Shape
{
	public static final int TR8 = 0;
	public static final int TR10 = 1;
	public static final int TR12 = 2;
	public static final int CODE8 = 3;
	public static final int CODE10 = 4;
	public static final int CODE12 = 5;
	public static final int TR12B = 5;

	private String text = "";
	private int size;
	private Font[] fontList = {
			new Font("TimesRoman", Font.PLAIN, 8),
			new Font("TimesRoman", Font.PLAIN, 10),
			new Font("TimesRoman", Font.PLAIN, 12),
			new Font("Monospaced", Font.PLAIN, 8),
			new Font("Monospaced", Font.PLAIN, 10),
			new Font("Monospaced", Font.PLAIN, 12),
			new Font("Times Roman", Font.BOLD, 12)};
	private Font fontType;
	private FontMetrics fm = null;

	public TextShape()
	{
		super(0,0,Shape.BLACK,Shape.DRAW);
		this.text = "";
		size = 12;
		fontType = fontList[TR12];
	}

	public TextShape(double x, double y, String text, int c)
	{
		super(x,y,c,Shape.DRAW);
		this.text = text;
		size = 12;
		fontType = fontList[TR12];
	}

	public TextShape(double x, double y, String text, int c, int font)
	{
		super(x,y,c,Shape.DRAW);
		this.text = text;
		fontType = fontList[font];
	}

	public TextShape copy()
	{
		TextShape t = new TextShape(x, y, text, colorIndex);

		return t;
	}

	public String getText()
	{ return text; }

	public void setText(String text)
	{ this.text = text; }

	public void setFont(int font)
	{
		fontType = fontList[font];
	}

	public void draw()
	{
		if (DrawTools.openWindowCalled == false)
			DrawTools.openWindow();

		if(!alist.contains(this))
			alist.add(this);

		DrawPanel panel = DrawTools.getDrawingPanel();

		drawFigure(panel.getGraphics(), panel.getFactor());
	}

	public void drawLeft()
	{
		if (DrawTools.openWindowCalled == false)
			DrawTools.openWindow();

		if(!alist.contains(this))
			alist.add(this);

		DrawPanel panel = DrawTools.getDrawingPanel();

		drawFigure(panel.getGraphics(), panel.getFactor());
	}

	public void drawFigure(Graphics g, double factor)
	{
		g.setColor(colorList[colorIndex]);
		g.setFont(fontType);
		fm = g.getFontMetrics(fontType);
		g.drawString(text, (int)(factor * x) - fm.stringWidth(text)/2,
			               (int)(factor * y + fm.getHeight()/4));
	}
}