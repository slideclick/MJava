package ds.graphics;

import java.awt.*;

public class RectShape extends Shape
{
   	private double length;
   	private double width;

   	public RectShape()
   	{
			super(0, 0, Shape.LIGHTGRAY, Shape.FILL);
			length = 0;
			width = 0;
  		}

   	public RectShape(double x, double y, double length, double width, int c)
   	{
			super(x, y, c, Shape.FILL);
			this.length = length;
			this.width = width;
  		}


   	public double getLength()
   	{  return length;  }

   	public double getWidth()
   	{  return width; }

		public void setSides(double length, double width)
		{
			this.length = length;
			this.width = width;
		}

   	public RectShape copy()
   	{
			RectShape r = new RectShape(x, y, length,  width, colorIndex);

			return r;
		}

   	public void draw()
   	{
			if (DrawTools.openWindowCalled == false)
				DrawTools.openWindow();

      	if(!alist.contains(this))
        		alist.add(this);

			DrawPanel panel = DrawTools.getDrawingPanel();

      	drawFigure(panel.getGraphics(), panel.getFactor());
   	}

   	public void drawFigure(Graphics g, double factor)
   	{
      	g.setColor(colorList[colorIndex]);
      	if(fillValue == Shape.FILL)
        		g.fillRect((int)(factor * x),(int)(factor * y),
                   (int)(factor * length), (int)(factor * width));
      	else
        		g.drawRect((int)(factor * x),(int)(factor * y),
                    (int)(factor * length), (int)(factor * width));
   	}
}