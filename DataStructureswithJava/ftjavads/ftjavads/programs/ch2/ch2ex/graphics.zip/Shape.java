package ds.graphics;

// package figures;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public abstract class Shape
{
  	public static final int DRAW = 1;
	public static final int FILL = 2;

  	public static final int WHITE = 0;
  	public static final int BLUE = 1;
  	public static final int TEAL = 2;
  	public static final int GREEN = 3;
  	public static final int MAGENTA = 4;
  	public static final int DARKGRAY = 5;
  	public static final int CYAN = 6;
  	public static final int PURPLE = 7;
  	public static final int LIGHTBLUE = 8;
  	public static final int LIGHTGRAY = 9;
  	public static final int GRAY = 10;
  	public static final int RED = 11;
  	public static final int ORANGE = 12;
  	public static final int PINK = 13;
  	public static final int YELLOW = 14;
  	public static final int BLACK = 15;

  	public static final int ONE = 1;
  	public static final int MANY = 2;

	protected static Color[] colorList =
		{ new Color(255,255,255), new Color(0,0,240),
		  new Color(0,128,128),   new Color(0,192,0),
		  new Color(255,0,255),   new Color(64,64,64),
		  new Color(0,255,255),   new Color(164,0,215),
		  new Color(181,218,255), new Color(192,192,192),
		  new Color(128,128,128), new Color(255,0,0),
		  new Color(255,200,0),   new Color(255,175,175),
		  new Color(255,255,0),   new Color(0,0,0)};

  	protected double x;
  	protected double y;
	protected int colorIndex = DARKGRAY;
  	protected int fillValue;

	protected static ArrayList<Shape> alist;

  	public Shape(double x, double y, int c, int fill)
  	{
		this.x = x;
		this.y = y;
		fillValue = fill;
		colorIndex = c;

    	if(alist == null)
      	alist = new ArrayList<Shape>();
  	}

  	public static ArrayList getShapes()
  	{ return alist; }

  	public static void clearShapes()
  	{
		alist.clear();
		DrawTools.getDrawingPanel().repaint();
	}

  	public void move(double x, double y)
  	{
    	this.x = x;
    	this.y = y;
	}

  	public void erase()
  	{
    	alist.remove(this);
		DrawTools.getDrawingPanel().repaint();
  	}

  	public double getX()
  	{ return x; }

  	public double getY()
  	{ return y; }


	public int getColor()
	{ return colorIndex; }

	public void setColor(int c)
	{ colorIndex = c; }

	public void nextColor()
	{ colorIndex = (colorIndex + 1) % colorList.length; }

  	public abstract void draw();
  	public abstract void drawFigure(Graphics g, double factor);
}